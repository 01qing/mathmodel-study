"""Validate signal classification experiment records; declared metadata, not scientific truth.

JSON fields: samples:[{id,group,split,label,fs_hz}], task_classes:[...],
fit_events:[{name,sample_ids,purpose,uses_labels}], metrics:[{name,split,truth,sample_ids}],
target_mode:'none'|'transductive', predictions:[{id,label}], required_target_ids:[...].
splits: train, validation, test, target. truth: independent_ground_truth, pseudo, absent.
Sample group must identify original acquisition including duplicate copies/channels/windows.
"""
import argparse,json,math
from pathlib import Path

def check(d):
    errors=[]; warnings=[]
    required=['samples','task_classes','fit_events','metrics','target_mode','predictions','required_target_ids']
    for k in required:
        if k not in d: errors.append('MISSING_FIELD:'+k)
    if errors: return {'status':'BLOCKED','errors':errors,'warnings':warnings}
    if d['target_mode'] not in ['none','transductive']: errors.append('INVALID_TARGET_MODE')
    if not d['samples'] or not d['task_classes']: errors.append('EMPTY_DATA_OR_CLASSES')
    if not d['fit_events']: errors.append('NO_FIT_PROVENANCE')
    ids={}; group_splits={}; classes=set(d['task_classes'])
    for s in d['samples']:
        if not all(k in s for k in ['id','group','split','label','fs_hz']):
            errors.append('INCOMPLETE_SAMPLE'); continue
        if not s['id'] or not s['group']: errors.append('MISSING_ID_OR_GROUP')
        if s['id'] in ids: errors.append('DUPLICATE_SAMPLE_ID:'+s['id'])
        ids[s['id']]=s
        if s['split'] not in ['train','validation','test','target']: errors.append('INVALID_SPLIT')
        group_splits.setdefault(s['group'],set()).add(s['split'])
        if not isinstance(s['fs_hz'],(int,float)) or not math.isfinite(s['fs_hz']) or s['fs_hz']<=0:
            errors.append('UNKNOWN_SAMPLING_RATE:'+s['id'])
        if s['split']!='target' and s['label'] not in classes: errors.append('INVALID_SOURCE_LABEL')
    for g,splits in group_splits.items():
        if len(splits)>1: errors.append('GROUP_CROSSES_SPLITS:'+g)
    for split in ['train','test']:
        found={s['label'] for s in ids.values() if s['split']==split}
        if found!=classes: errors.append('CLASS_COVERAGE:'+split)
    for e in d['fit_events']:
        if not all(k in e for k in ['name','sample_ids','purpose','uses_labels']): errors.append('INCOMPLETE_FIT_EVENT'); continue
        if not e['sample_ids']: errors.append('EMPTY_FIT_EVENT:'+e['name'])
        for sid in e['sample_ids']:
            if sid not in ids: errors.append('UNKNOWN_FIT_SAMPLE:'+sid); continue
            split=ids[sid]['split']
            allowed=(split=='train' or (split=='validation' and e['purpose']=='tuning') or
                (split=='target' and d['target_mode']=='transductive' and e['purpose']=='adaptation' and e['uses_labels'] is False))
            if not allowed: errors.append('FIT_BOUNDARY:'+e['name']+':'+sid)
    for m in d['metrics']:
        if not all(k in m for k in ['name','split','truth','sample_ids']): errors.append('INCOMPLETE_METRIC'); continue
        if not m['sample_ids']: errors.append('EMPTY_METRIC_POPULATION')
        for sid in m['sample_ids']:
            if sid not in ids or ids[sid]['split']!=m['split']: errors.append('METRIC_POPULATION_MISMATCH')
        if m['name'] in ['accuracy','f1','macro_f1','balanced_accuracy','recall','auc']:
            if m['truth']!='independent_ground_truth': errors.append('UNSUPPORTED_ACCURACY:'+m['split'])
            if any(sid not in ids or ids[sid]['label'] not in classes for sid in m['sample_ids']):
                errors.append('METRIC_TRUTH_MISSING')
            if m['split']=='target' and not any(s['split']=='target' and s['label'] in classes for s in ids.values()):
                errors.append('TARGET_TRUTH_MISSING')
        if m['split']=='validation': warnings.append('Validation used for selection is not a final unbiased estimate')
    predids=[p.get('id') for p in d['predictions']]
    if len(predids)!=len(set(predids)): errors.append('DUPLICATE_PREDICTION')
    if set(predids)!=set(d['required_target_ids']): errors.append('TARGET_OUTPUT_COVERAGE')
    if any(p.get('label') not in classes for p in d['predictions']): errors.append('INVALID_PREDICTION_LABEL')
    warnings.append('Only declared metadata checked; verify actual file hashes, code and metric provenance')
    return {'status':'BLOCKED' if errors else 'METADATA_CHECK_PASS','errors':sorted(set(errors)),'warnings':sorted(set(warnings))}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('record',type=Path);a=p.parse_args()
    try: result=check(json.loads(a.record.read_text(encoding='utf-8')))
    except (ValueError,TypeError,KeyError,AttributeError) as e: result={'status':'BLOCKED','errors':['MALFORMED_RECORD:'+str(e)]}
    print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['status']=='METADATA_CHECK_PASS' else 1)
