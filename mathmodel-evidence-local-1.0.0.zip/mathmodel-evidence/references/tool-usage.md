# 脚本使用范围

`compare_features.py`需要Python、NumPy、scikit-learn。输入CSV包含path、channel、label、fs_used、seg_idx，其余列须为经确认可用于预测的有限数值特征。未知的标识符或泄漏特征列不要直接当输入。path用于原文件分组，不能替代内容哈希查重。

运行：`python scripts/compare_features.py 特征表.csv 结果.json --folds 3`。
输出随机行/文件分组三折对照、窗口/文件两种指标、分类混淆矩阵和每折测试组。任何折缺类别即失败，需重新设计验证，不通过不断换种子挑高分。分组表应先人工核实。这个脚本不从原始波形提取特征，不做真实目标域适应，也不自动决定最终模型。

`check_experiment.py`仅用Python标准库，适用于信号分类实验的元数据检查。输入格式见[example-experiment.json](example-experiment.json)，它是合成说明样例，不是实际赛题记录。

运行：`python scripts/check_experiment.py 实验记录.json`。
退出码0表示声明的元数据检查通过，1表示缺字段或边界问题。fs_hz须为已核实的实际采样率；sample_ids指向实际样本；group应跨副本、通道和切窗保留同次采集标识。fit_events记录训练变换、模型拟合及适应等所有真实操作；漏报操作会逃过检查，因此仍要查看执行日志和代码。

target_mode为transductive时允许无标签目标特征参与adaptation；不允许把它误报为完全未见目标数据的泛化实验。已知真实目标标签可用于冻结后的评价，但不得参与无监督适应。purpose=tuning允许使用validation；它不把validation分数升级为独立测试证据。

本次真实运行与测试材料保存在`D:/softdown/codex/mathmodel-study/evidence`。重新计算参考特征诊断需使用本地原CSV；发布技能包不附带用户的全部论文或代码。
