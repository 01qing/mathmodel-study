# ROLE-P1-2022C Orchestration Handoff v0.2

Status: READY_FOR_ISOLATED_RUN_A
Date: 2026-09-21

## Core

`release-v141.zip` is now available and has been verified.

Wrapper SHA256:
`a4ef5b69d31ab2b5de032e9fa9e8c78f15a09b773bfca3ace57870cdb418016f`

Internal sealed Core:
- version: 1.41.0
- status: SEALED
- Core ZIP SHA256: `191c4dad37c811049516c66862bd2d45d1364784ff277ec73e5667d07cb64d6f`
- bytes: 206263605
- entries: 2341
- ZIP test: PASS

Run A and Run B v0.2 packages embed this exact verified wrapper.

## Official 2022-C source identity

The same five official source files must be uploaded separately to A and B:
- problem DOCX: Git blob SHA1 `d11123561801c4f15e308b55b72ff97a7f4e24b8`, 388087 bytes
- attachment1.xlsx: `3ad2e09e579bf65c0435789e101fd7d2c9a0d9e5`, 15262 bytes
- attachment2.xlsx: `c5747522b104cc1fb2c2814feeec2ab215a76be7`, 15402 bytes
- attachment3.xlsx: `a297c0a708cdaf88769614f01b9b5dc177d01535`, 10138 bytes
- attachment4.xlsx: `50d1da619d1269949833614935d5eb0cba75219d`, 9196 bytes

The orchestration chat must not inspect/solve these files.

## Execution order

1. Fresh Chat A: Run A v0.2 + official five files only.
2. Freeze A bundle.
3. Fresh Chat B: Run B v0.2 + same official five files only.
4. Freeze B bundle.
5. Anonymize A/B as X/Y without revealing mapping.
6. Fresh Chat C: Run C v0.2 + official five files + X/Y.
7. Freeze blind evaluation at `BLIND_EVALUATION_FROZEN`.
8. Reveal mapping and compute predefined criterion-level differences.

## Do not

- run A and B in the same chat;
- give B any A output;
- give A any B interface/prompt;
- open 2022-C excellent papers or reference solutions before blind evaluation freeze;
- modify MathModel-Core v1.41 during the experiment;
- infer causal role superiority from the 2022-D smoke fixture.

## Current evidence status

- 2022-D role-pipeline smoke: PASS within scoped smoke/evidence closure.
- 2022-C paired benchmark: REGISTERED / NOT_RUN.
- Role specialization causal improvement: NOT_ESTABLISHED.
- Controlled Core Ablation: NOT_RUN.
