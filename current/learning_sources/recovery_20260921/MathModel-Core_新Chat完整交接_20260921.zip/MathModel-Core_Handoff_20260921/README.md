# MathModel-Core handoff package — 2026-09-21

Start with:

1. `MathModel-Core_新Chat总交接_20260921.md`
2. `UPLOAD_CHECKLIST.md`

If creating a new orchestration chat, use:

- `NEW_ORCHESTRATION_CHAT_FIRST_PROMPT.txt`

If starting the actual isolated role experiment, do **not** feed the orchestration handoff to Run A/B. Use:

- `RUN_A_FIRST_PROMPT.txt`
- `RUN_B_FIRST_PROMPT.txt`
- `RUN_C_FIRST_PROMPT.txt`

The large v0.2 A/B/C run ZIPs are intentionally not duplicated into this compact handoff package. Use the separately generated v0.2 run packages and verify their SHA256 values listed in the master handoff.
