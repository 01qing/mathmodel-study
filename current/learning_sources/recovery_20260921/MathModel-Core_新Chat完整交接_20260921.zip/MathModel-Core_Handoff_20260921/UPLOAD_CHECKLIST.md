# 新 Chat 文件上传清单

## A. 如果你要建立新的“项目总控 Chat”

必须上传：
1. `MathModel-Core_新Chat总交接_20260921.md`
2. `NEW_ORCHESTRATION_CHAT_FIRST_PROMPT.txt`

建议上传：
3. `ROLE-P1-2022C_ORCHESTRATION_TEXT_PACK_v0.2.zip`
4. `Graduate-MathModel-Learning-Skill-v1.41.release.json`
5. `ROLE_P1_2022C_SHA256SUMS_v0.2.txt`

不要上传：
- 2022-C官方题面/附件；
- A/B solution bundle；
- 优秀论文/答案。

原因：总控 Chat 不应读取或解2022-C。

---

## B. 真正开始 Fresh Chat A

只上传：
1. `ROLE-P1-2022C_RUN_A_SINGLE_CORE_v0.2.zip`
2. `2022C_官方题面_汽车制造公司涂装-总装缓存区调序调度优化问题.docx`
3. `2022C_附件1.xlsx`
4. `2022C_附件2.xlsx`
5. `2022C_附件3.xlsx`
6. `2022C_附件4.xlsx`

第一句话：粘贴 `RUN_A_FIRST_PROMPT.txt`。

不要上传：
- 本总交接包；
- Run B；
- Run C；
- A/B比较历史；
- 2022-D smoke总结；
- 2022-C优秀论文/答案。

---

## C. Fresh Chat B

必须等 A 已冻结。

只上传：
1. `ROLE-P1-2022C_RUN_B_ARCHITECT_REVIEWER_v0.2.zip`
2. 与 A 完全相同的官方5文件。

第一句话：粘贴 `RUN_B_FIRST_PROMPT.txt`。

禁止上传：
- A output；
- A score；
- A model choice；
- Run C prompt。

---

## D. Fresh Chat C — Blind Evaluator

必须等 A/B 均冻结并匿名成 X/Y。

上传：
1. `ROLE-P1-2022C_RUN_C_BLIND_EVALUATOR_v0.2.zip`
2. 官方5文件；
3. anonymous X bundle；
4. anonymous Y bundle；
5. filled experiment registry / isolation metadata。

第一句话：粘贴 `RUN_C_FIRST_PROMPT.txt`。

C 必须以 `BLIND_EVALUATION_FROZEN` 结束，之后才能揭盲。
