# Blind Evaluation Contamination Guard

Before `BLIND_EVALUATION_FROZEN`, prohibited:
- 2022-C excellent papers / reference answers / solution articles / solution code;
- external searches for 2022-C solutions;
- original labeled condition bundles or condition summaries;
- private X/Y reveal mapping;
- attempts to infer or request hidden workflow identity.

Permitted:
- official problem + four official attachments;
- Anonymous Bundle X/Y;
- generic software/documentation needed to execute already-declared methods, provided it is not 2022-C solution material.

If prohibited exposure occurs, record the exposure and stop the blind claim.
