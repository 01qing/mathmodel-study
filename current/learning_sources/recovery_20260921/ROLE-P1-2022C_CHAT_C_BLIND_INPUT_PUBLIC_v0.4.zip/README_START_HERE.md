# Chat C Blind Evaluation Input

Status: `READY_FOR_BLIND_EVALUATION`

Upload to a **fresh Chat C**:
1. this public input pack (or its individual public files);
2. the same five official 2022-C source files used by both frozen runs.

Do **not** upload any private reveal key, original labeled condition bundle, orchestration handoff, or labeled condition summary.

Anonymous bundle integrity:
- X SHA256: `d5afc994f9f6854fd9fdc0bb6d6c96b6c92686f55f62a9ffb8304f3752b29b88`
- Y SHA256: `fea607abe801d8a2bd40803f1e25423cb21e4243b26046861a4bf44980d3f4e8`

First message: use `RUN_C_BLIND_EVALUATOR_PROMPT_v0.4.txt`.

The evaluator must finish with `BLIND_EVALUATION_FROZEN` before identity reveal.
